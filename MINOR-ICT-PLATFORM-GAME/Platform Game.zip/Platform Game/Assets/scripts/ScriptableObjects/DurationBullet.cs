﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class DurationBullet : ScriptableObject
{
    public int duration;
}

